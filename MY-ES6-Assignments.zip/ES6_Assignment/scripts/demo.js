"use strict";
console.log('hello world');
//# sourceMappingURL=demo.js.map