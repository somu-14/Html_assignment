let details = ["abcd", "xyz", "Female", "bangalore"];

let [fname, lname, gender, place] = details;

console.log(details[2]);