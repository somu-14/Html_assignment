let add = function (a = 10, b = 30) {
    console.log("Add of two numbers: ", a + b);
};
add();

