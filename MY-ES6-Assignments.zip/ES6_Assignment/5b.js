let userFriends = function (username, ...friends) {
    console.log(username);
    console.log(friends);
};

userFriends("Abc", "xyz", "john", "pqr");